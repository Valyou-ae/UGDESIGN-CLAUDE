# 📋 POD Mockup Generator - Unified Personas Library

## Overview

Complete persona library for AI-powered POD (Print-on-Demand) mockup generation. This library provides **288 unique personas** covering all demographic combinations needed for diverse, inclusive mockup images.

---

## 📊 Specifications

| Attribute | Options | Count |
|-----------|---------|-------|
| **Ethnicities** | White, Black, Hispanic, Asian, Indian, Southeast Asian, Indigenous, Middle Eastern | 8 |
| **Sizes** | XS, S, M, L, XL, 2XL | 6 |
| **Age Groups** | Teen (13-17), Young Adult (18-24), Adult (25-45) | 3 |
| **Sexes** | Male, Female | 2 |
| **Total Personas** | 8 × 6 × 3 × 2 | **288** |

---

## 📁 File Structure

```
personas/
├── index.ts              # Main entry point with unified exports
├── types.ts              # TypeScript type definitions
├── adultPersonas.ts      # Adult personas (25-45 years) - 96 personas
├── teenPersonas.ts       # Teen personas (13-17 years) - 96 personas
└── youngAdultPersonas.ts # Young Adult personas (18-24 years) - 96 personas
```

---

## 🚀 Replit Integration Guide

### Step 1: Add Files to Your Replit Project

1. Create a `personas/` folder in your project root
2. Copy all `.ts` files into the `personas/` folder
3. Ensure your `tsconfig.json` includes the personas directory

### Step 2: Import in Your Code

```typescript
// Import everything
import PersonaLibrary from './personas';

// Or import specific items
import { 
  getPersona, 
  getRandomPersona, 
  allPersonas,
  Persona,
  Ethnicity,
  Size,
  AgeGroup
} from './personas';
```

### Step 3: Basic Usage

```typescript
// Get a specific persona
const persona = getPersona('Adult', 'Middle Eastern', 'Female', 'M');
console.log(persona?.fullDescription);

// Get random persona
const random = getRandomPersona();

// Get random persona with criteria
const randomTeen = getRandomPersona({ ageGroup: 'Teen', sex: 'Male' });

// Filter personas
import { getPersonas } from './personas';
const allAsianFemales = getPersonas({ ethnicity: 'Asian', sex: 'Female' });
```

### Step 4: Generate AI Prompts

```typescript
import { generatePrompt, getModelDescription } from './personas';

const persona = getPersona('Young Adult', 'Hispanic', 'Female', 'L');

// Full prompt for AI image generation
const fullPrompt = generatePrompt(persona);
// Output: "Daniela is a 21-year-old young adult female of Hispanic heritage..."

// Concise model description
const modelDesc = getModelDescription(persona);
// Output: "18-24 year old female of Hispanic heritage, sturdy athletic frame..."
```

### Step 5: Validate Coverage

```typescript
import { validateCoverage, PERSONA_STATS } from './personas';

// Check if all 288 combinations exist
const validation = validateCoverage();
console.log(`Coverage: ${validation.coverage}%`);
console.log(`Complete: ${validation.isComplete}`);

// View statistics
console.log(PERSONA_STATS);
```

---

## 🔧 Integration with Mockup Generator

### Connecting to Your Prompt Builder

```typescript
// In your promptBuilder.ts or equivalent

import { getPersona, generatePrompt } from './personas';

export function buildMockupPrompt(config: {
  ageGroup: 'Teen' | 'Young Adult' | 'Adult';
  ethnicity: string;
  sex: 'Male' | 'Female';
  size: string;
  product: string;
  design: string;
}) {
  // Get the persona
  const persona = getPersona(
    config.ageGroup,
    config.ethnicity as Ethnicity,
    config.sex,
    config.size as Size
  );
  
  if (!persona) {
    throw new Error(`Persona not found for: ${JSON.stringify(config)}`);
  }
  
  // Build the complete prompt
  return `
    ${persona.fullDescription}
    
    Wearing a ${config.product} with ${config.design} design.
    Professional product photography, lifestyle mockup, high quality.
  `;
}
```

### Connecting to Your UI/Frontend

```typescript
// In your frontend selection component

import { ETHNICITIES, SIZES, QUICK_REF } from './personas';

// Populate dropdowns
const ethnicityOptions = QUICK_REF.ethnicities;
const sizeOptions = QUICK_REF.sizes;
const ageOptions = QUICK_REF.ageGroups;
const sexOptions = QUICK_REF.sexes;
```

---

## 📋 Persona Data Structure

Each persona contains:

```typescript
interface Persona {
  id: string;           // e.g., "MDE_AD_F_M_001"
  name: string;         // e.g., "Amira"
  age: AgeGroup;        // 'Teen' | 'Young Adult' | 'Adult'
  ageRange: string;     // e.g., "25-45"
  sex: Sex;             // 'Male' | 'Female'
  ethnicity: Ethnicity; // e.g., 'Middle Eastern'
  size: Size;           // 'XS' | 'S' | 'M' | 'L' | 'XL' | '2XL'
  height: string;       // e.g., '168cm (5\'6")'
  weight: string;       // e.g., '65kg (143lbs)'
  build: string;        // e.g., 'Average athletic frame'
  facialFeatures: string;
  hairStyle: string;
  hairColor: string;
  eyeColor: string;
  skinTone: string;
  fullDescription: string; // Complete AI-ready description
  version: string;
  createdDate: string;
}
```

---

## 🆔 ID Format

Persona IDs follow this pattern: `{ETHNICITY}_{AGE}_{SEX}_{SIZE}_001`

| Code | Meaning |
|------|---------|
| **Ethnicity Codes** | WHT, BLK, HSP, ASN, IND, SEA, IDG, MDE |
| **Age Codes** | TN (Teen), YA (Young Adult), AD (Adult) |
| **Sex Codes** | F (Female), M (Male) |
| **Size** | XS, S, M, L, XL, 2XL |

**Examples:**
- `MDE_AD_F_M_001` = Middle Eastern Adult Female Medium
- `BLK_TN_M_XL_001` = Black Teen Male XL
- `ASN_YA_F_S_001` = Asian Young Adult Female Small

---

## ✅ Verification Checklist

Run this to verify all personas are loaded:

```typescript
import { validateCoverage, PERSONA_STATS } from './personas';

const check = validateCoverage();

console.log('=== PERSONA LIBRARY VERIFICATION ===');
console.log(`Total Personas: ${PERSONA_STATS.totalPersonas}`);
console.log(`Coverage: ${check.coverage}%`);
console.log(`Complete: ${check.isComplete ? '✅ YES' : '❌ NO'}`);

if (!check.isComplete) {
  console.log('Missing:', check.missing);
}
```

Expected output:
```
=== PERSONA LIBRARY VERIFICATION ===
Total Personas: 288
Coverage: 100%
Complete: ✅ YES
```

---

## 📦 Quick Start for Replit

```bash
# 1. In your Replit shell, create the directory
mkdir -p personas

# 2. Upload all the .ts files to the personas/ folder

# 3. In your main file, import and test:
```

```typescript
// test.ts
import { allPersonas, validateCoverage, PERSONA_STATS } from './personas';

console.log('Loaded', allPersonas.length, 'personas');
console.log('Stats:', PERSONA_STATS);
console.log('Validation:', validateCoverage());
```

---

## 🎯 Coverage Matrix

### By Age Group
| Age Group | Female | Male | Total |
|-----------|--------|------|-------|
| Teen (13-17) | 48 | 48 | 96 |
| Young Adult (18-24) | 48 | 48 | 96 |
| Adult (25-45) | 48 | 48 | 96 |
| **TOTAL** | **144** | **144** | **288** |

### By Ethnicity (each has 36 personas)
| Ethnicity | Teen | Young Adult | Adult | Total |
|-----------|------|-------------|-------|-------|
| White | 12 | 12 | 12 | 36 |
| Black | 12 | 12 | 12 | 36 |
| Hispanic | 12 | 12 | 12 | 36 |
| Asian | 12 | 12 | 12 | 36 |
| Indian | 12 | 12 | 12 | 36 |
| Southeast Asian | 12 | 12 | 12 | 36 |
| Indigenous | 12 | 12 | 12 | 36 |
| **Middle Eastern** | 12 | 12 | 12 | 36 |
| **TOTAL** | **96** | **96** | **96** | **288** |

---

## 📝 Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0 | 2025-12-28 | Added Middle Eastern ethnicity, updated to 6 sizes (XS-2XL), 3 age groups |
| 1.0 | 2025-12-04 | Initial release with 7 ethnicities |

---

## 🆘 Troubleshooting

### "Cannot find module './personas'"
- Ensure all files are in the `personas/` folder
- Check your import path is correct

### "Persona not found"
- Verify ethnicity spelling matches exactly (case-sensitive)
- Verify size is one of: 'XS', 'S', 'M', 'L', 'XL', '2XL'
- Verify age group is one of: 'Teen', 'Young Adult', 'Adult'

### TypeScript errors
- Ensure `types.ts` is imported correctly
- Check your tsconfig includes the personas directory

---

*Last Updated: December 28, 2025*
